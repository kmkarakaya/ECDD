# Sync plan: paper.md → main.tex (section-by-section)

Use this checklist to verify titles, text, figures, and tables match `paper.md`. Mark each item as synced when copied/verified in `main.tex`.

## I. INTRODUCTION
- [x] Section title matches (`\section{Introduction}`)
- [x] Text matches (incl. 3 pillars list)
- [x] Fig. 1 (`workflow.png`) + caption matches


## II. EXPLICIT CONTEXT-DRIVEN DEVELOPMENT (ECDD)
### II.A Design Principles
- [x] Section/subsection titles match
- [x] Bullet list matches
- [x] Table 1 content matches


### II.B Executable Prompts as Workflow Contracts
- [x] Titles/subtitles match (B.1/B.2/B.3 structure)
- [x] Table 2 content matches
- [x] Table 3 content matches
- [x] Execution semantics paragraphs match
- [x] Resource binding paragraph matches


### II.C Artifact Model and Traceability
- [x] Titles match
- [x] Enumerated artifact list matches (1–6)
- [x] Template explanation paragraphs match
- [x] Table 4 content matches
- [x] Traceability chain sentence matches
- [x] Fig. 3 (`traceability_loop.png`) + caption matches


### II.D Workflow Instantiation in Practice
- [x] Title matches
- [x] Paragraphs match
- [x] Numbered steps (Define/Plan/Elaborate/Scope/Implement) match


## III. RUNNING EXAMPLE (WALKTHROUGH)
- [x] Section title matches
- [x] Define/Plan/Elaborate/Scope/Implement walkthrough text matches



## IV. DISCUSSION
- [ ] Section title matches
- [ ] Text matches

## V. CONCLUSION
- [ ] Section title matches
- [ ] Text matches
