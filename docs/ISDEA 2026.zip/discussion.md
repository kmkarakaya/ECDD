# IV. DISCUSSION AND LIMITATIONS

Section II described ECDD as a workflow package built from executable prompts, template-shaped intermediate artifacts, and a repository structure that keeps project state explicit (Fig. 2). This design is intentionally conservative: rather than maximizing autonomy, ECDD optimizes for developer control, predictable handoffs, and auditability across sessions and tools (Fig. 1, Tables 1-3).

## A. Practical Lessons and Limitations

This paper does not report controlled benchmarking results for ECDD. The discussion below reflects informal observations from toy projects and focuses on methodological rationale rather than measured improvements.

Compared to informal vibe coding, ECDD's primary advantage is not that models "know more," but that they are repeatedly grounded in the same, reviewable context. Governance prompts and scoped AI instructions help reduce behavioral drift; template-shaped artifacts reduce variability in intermediate documents; and append-only logs make it easier to reconstruct what changed and why. This aims to strengthen alignment between intent and implementation, especially when multiple developers or agents contribute to the same codebase over time.

ECDD also introduces costs. Maintaining prompts, templates, and artifacts takes time, and the up-front effort can feel disproportionate for small or short-lived prototypes. The overhead is typically easier to justify when the project has a longer lifetime, when multiple contributors are expected, or when the domain carries non-trivial risk (privacy, safety, or regulatory constraints). For exploratory work, a lighter subset of the method (e.g., a project definition plus scoped AI instructions) may be sufficient.

A second limitation is the risk of over-constraining work through templates. While templates function as lightweight schemas that reduce omissions (acceptance criteria, verification steps, and explicit assumptions), they can also encourage "checkbox compliance" or fail to capture domain-specific nuance if not tailored. ECDD therefore relies on teams treating templates as living standards that evolve with project and company needs, and on developers exercising judgment when reviewing artifacts at each human-in-the-loop checkpoint.

Prompt bloat is a related failure mode. If governance and workflow prompts accumulate every rule and edge case, they become difficult to read and may dilute the most important constraints. ECDD works best when prompt files are curated like code: periodically refactored, split into focused components, and kept consistent with the current repository structure and conventions.

Because prompts are executable inputs to LLM systems, they can also become an attack surface (e.g., backdoor attacks targeting prompt-engineered code generation) [14].

Finally, ECDD can create a false sense of assurance. Explicit plans, logs, and checklists make auditing easier, but they do not guarantee correctness or robustness. Mis-specified requirements, superficial tests, or incomplete reviews can still lead to defects. In addition, storing rich context in a repository can raise confidentiality concerns; teams need appropriate access control and redaction practices when artifacts contain sensitive information.

From a tooling perspective, ECDD assumes teams are comfortable with plain-text artifacts in version control and can connect them to their preferred AI assistants. While a file such as `copilot-instructions.md` in the `.github/` folder provides a straightforward integration point for some tools, broader adoption would benefit from richer automation, such as IDE affordances that surface the relevant prompt and artifact for the current task, and integrations with CI, issue trackers, and documentation systems.

## B. Relation to Existing Work

ECDD sits at the intersection of several threads of work on software development practice. From one angle, it can be seen as a pragmatic descendant of specification-driven and model-driven development, but with LLMs in the loop and with a stronger emphasis on treating prompts themselves as artifacts. Like configuration-as-code and infrastructure-as-code approaches [11], it insists that important project knowledge live in version-controlled text files rather than in wikis, tickets, or team folklore.

Compared to traditional style guides and architecture decision records (ADRs), ECDD's governance prompts are more tightly coupled to AI tools: they are written to be consumed both by developers and by LLMs, and they are referenced explicitly in planning, execution, and verification prompts. This dual audience influences their structure and language, pushing teams toward more precise but still natural-language descriptions of goals, constraints, and patterns. ECDD is also aligned with long-standing concerns in requirements traceability [10], but shifts the traceability chain toward AI-facing, repository-native artifacts that can be consumed directly by prompts and coding agents.

ECDD also connects to a growing body of work on prompting and agentic software engineering. Survey work catalogues prompt patterns and prompting techniques [5], [6], while prompt-based LLM approaches have also been evaluated for requirements engineering tasks such as requirements classification [15]. Agent architectures such as ReAct combine reasoning and tool use to structure multi-step behavior [7]. More recent software engineering agents (e.g., SWE-agent) explicitly separate planning, file reading, editing, and verification steps and are often evaluated on benchmarks such as SWE-bench [8], [9]. ECDD deliberately chooses a different point in this design space: instead of optimizing for autonomy, it assumes human-in-the-loop control and focuses on making collaboration structured, observable, and reviewable by externalizing project state into template-shaped artifacts.

## C. Threats to Validity

ECDD is presented here as a methodology and reference workflow package, and this paper does not report controlled outcome measurements. As a result, threats to validity primarily concern how one should interpret the claimed benefits and how future evaluations should be designed.

Construct validity is a first concern: terms such as "quality," "traceability," and "context drift" are multi-dimensional. Proxy measures (e.g., artifact completeness, acceptance-criteria coverage, test presence, or diff reviewability) may correlate with real outcomes but do not guarantee them. Similarly, a well-structured `log.md` may improve auditability without improving correctness if the logged decisions are flawed.

Internal validity is threatened by confounders such as developer experience, domain complexity, model capability, and tool integration. For example, better outcomes may come from increased attention during artifact reviews rather than from the prompt/template mechanism itself. Comparative studies must therefore control for review effort, task difficulty, and prior familiarity with the codebase.

External validity is threatened by domain and organizational variance. Some domains may resist template shaping (e.g., highly exploratory research prototypes), while regulated domains may require additional governance layers beyond what our templates include. In addition, storing rich context in a repository can raise confidentiality and compliance concerns; organizations may need access control, redaction, or internal hosting policies to adopt artifact-centric workflows safely.