# III. RUNNING EXAMPLE (WALKTHROUGH)

This section provides a lightweight, method-only walkthrough that illustrates how the artifacts and prompts described in Section II interact in practice. The example uses a small web application, "AI Concepts Dictionary": a user enters an AI concept and the system returns a structured definition, short examples, and related resources. The specific domain is incidental; the goal is to show the ECDD artifact chain and the human-in-the-loop revision checkpoints that replace reliance on chat memory.

**Define (creates a project definition):** After running the Define prompt, the agent produces a first draft of `project_definition.md` in the artifacts folder. The developer reviews and may revise it before planning continues. The excerpt below is illustrative and abridged:

```markdown
# Project Definition (MVP)

## 1. Project Essentials

**Project Name:** AI Concepts Dictionary
**What does this project do?** A web app that returns structured definitions, examples, and resources for AI concepts.
**Who will use it?** Learners and practitioners.

## 3. Technical Basics

### Tech Stack
- Frontend: React + Vite
- Backend: Node.js + Express (API proxy)
- Deployment: local dev + cloud hosting

### Constraints & Risks
- Security: do not hard-code API keys; use environment variables
- Known Risks: inconsistent outputs without templates and acceptance criteria
```

**Plan (creates a roadmap):** Running the Plan prompt converts the (developer-reviewed) project definition into a dependency-aware roadmap saved as `workpackage_list.md` in the artifacts folder:

```markdown
### WP-001 Project scaffold and build system
- **Priority:** High
- **Effort:** Small
- **Dependencies:** None
- **Description:** Create the repo structure, build scripts, and baseline CI/test scaffolding.

### WP-002 LLM-backed definition API
- **Priority:** High
- **Effort:** Medium
- **Dependencies:** WP-001
- **Description:** Implement an API endpoint that queries the configured LLM and returns a structured response.

### WP-003 UI: search + results view
- **Priority:** High
- **Effort:** Medium
- **Dependencies:** WP-001, WP-002
- **Description:** Build the UI input, results layout, and error/loading states.
```

**Elaborate (creates a detailed spec):** The developer selects a work package (e.g., `WP-002`) and runs Elaborate to generate `workpackage_WP-002.md`. The artifact is then reviewed and can be revised before any code is written:

```markdown
# WP-002 LLM-backed definition API

## 2. Acceptance Criteria
- [ ] Given a concept string, the API returns a JSON object with fields: definition, examples, resources
- [ ] API rejects empty input and returns a clear error message
- [ ] API reads the LLM API key from an environment variable

## 3. Technical Specifications
### Files to Create/Modify
- server/src/routes/define.ts: add POST /api/define
- server/src/llm/client.ts: wrap LLM calls and retries

## 5. Testing Requirements
- Unit tests for input validation and response shape
```

**Scope (generates coding-agent instructions):** Once artifacts are reviewed, the developer runs Scope to generate `copilot-instructions.md` in the `.github/` folder. This file summarizes the current project context and coding guidelines so coding agents operate from the same explicit state, even when tools or sessions change.

**Implement (creates a checklist and append-only log):** Finally, the developer runs Implement for a selected WP. The agent creates or updates `todos_WP-002.md` (artifacts folder) and appends an entry to `log.md` (artifacts folder). Both artifacts support resumable execution and post-hoc audit:

```markdown
## todos_WP-002.md (excerpt)
- [ ] Implement request validation and error responses
- [ ] Implement LLM client wrapper with timeouts and retries
- [ ] Implement POST /api/define route and response shaping
- [ ] Add unit tests for validation and response schema
- [ ] Update log.md with files touched and key decisions
```

The key methodological feature is the revision loop: after each phase, the developer can correct scope, standards, dependencies, or acceptance criteria directly in version-controlled artifacts, and subsequent prompts consume the revised state as input (Fig. 3). This makes the workflow reproducible across sessions and tools and keeps the developer in control of project intent.
